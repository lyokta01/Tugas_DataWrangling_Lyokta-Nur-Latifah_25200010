"""
generate_dummy_data.py
Membangkitkan dataset dummy PT Nusantara Retail Mandiri:
  1. transaksi_pos.csv     -> Divisi Kasir/POS
  2. crm_loyalty.db        -> Divisi CRM (SQLite, tabel customers)
  3. logistik_mock.json    -> Respons mock REST API mitra ekspedisi (nested JSON)
"""
import json
import os
import sqlite3

import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
BASE = os.path.dirname(os.path.abspath(__file__))

N_CUSTOMER, N_ORDER = 120, 500
CITIES = ["Jakarta", "Bandung", "Surabaya", "Semarang", "Yogyakarta",
          "Medan", "Makassar", "Denpasar", "Pemalang", "Tegal"]
PROV = {"Jakarta": "DKI Jakarta", "Bandung": "Jawa Barat", "Surabaya": "Jawa Timur",
        "Semarang": "Jawa Tengah", "Yogyakarta": "DI Yogyakarta", "Medan": "Sumatera Utara",
        "Makassar": "Sulawesi Selatan", "Denpasar": "Bali", "Pemalang": "Jawa Tengah",
        "Tegal": "Jawa Tengah"}
FIRST = ["Budi", "Siti", "Agus", "Dewi", "Rina", "Eko", "Putri", "Andi", "Wulan", "Hadi",
         "Nanda", "Fajar", "Intan", "Rizky", "Maya", "Dimas", "Lestari", "Yoga", "Sari", "Bagus"]
LAST = ["Santoso", "Wijaya", "Pratama", "Lestari", "Hidayat", "Saputra", "Kusuma",
        "Nugroho", "Rahmawati", "Setiawan"]

# ---------- 1. CRM (SQLite) ----------
cust_ids = [f"CUST{i:04d}" for i in range(1, N_CUSTOMER + 1)]
customers = pd.DataFrame({
    "customer_id": cust_ids,
    "customer_name": [f"{rng.choice(FIRST)} {rng.choice(LAST)}" for _ in cust_ids],
    "membership_tier": rng.choice(["Bronze", "Silver", "Gold", "Platinum"], N_CUSTOMER,
                                  p=[.4, .3, .2, .1]),
    "city": rng.choice(CITIES, N_CUSTOMER),
    "join_date": pd.to_datetime("2022-01-01") + pd.to_timedelta(rng.integers(0, 1400, N_CUSTOMER), "D"),
    "is_active": rng.choice([1, 0], N_CUSTOMER, p=[.88, .12]),
})
customers["join_date"] = customers["join_date"].dt.strftime("%Y-%m-%d")
db_path = os.path.join(BASE, "crm_loyalty.db")
if os.path.exists(db_path):
    os.remove(db_path)
with sqlite3.connect(db_path) as con:
    customers.to_sql("customers", con, index=False)

# ---------- 2. Transaksi POS (CSV) ----------
# sebagian kecil transaksi berasal dari pelanggan non-member (tidak ada di CRM)
pool = cust_ids + [f"GUEST{i:03d}" for i in range(1, 11)]
order_ids = [f"ORD{20260800 + i:08d}" for i in range(1, N_ORDER + 1)]
dates = pd.to_datetime("2026-08-01") + pd.to_timedelta(rng.integers(0, 60, N_ORDER), "D")
coupon = rng.choice(["", "AKHIRBULAN20", "GAJIAN15", "HEMAT10"], N_ORDER, p=[.6, .2, .12, .08])
amount = (rng.integers(50, 1500, N_ORDER) * 1000)
trx = pd.DataFrame({
    "order_id": order_ids,
    "customer_id": rng.choice(pool, N_ORDER),
    "order_date": dates.strftime("%Y-%m-%d"),
    "store_id": rng.choice(["TKO-JKT", "TKO-BDG", "TKO-SBY", "ONLINE"], N_ORDER),
    "coupon_code": coupon,
    "total_amount": amount,
})
trx.loc[trx["coupon_code"] == "", "coupon_code"] = np.nan
trx.to_csv(os.path.join(BASE, "transaksi_pos.csv"), index=False)

# ---------- 3. Mock REST API logistik (nested JSON) ----------
# ~92% pesanan sudah diserahkan ke kurir; sisanya belum ada di sistem ekspedisi
shipped = rng.choice(order_ids, int(N_ORDER * .92), replace=False)
results = []
for oid in sorted(shipped):
    city = rng.choice(CITIES)
    status = rng.choice(["Delivered", "In Transit", "Pending Pickup", "Returned"],
                        p=[.62, .24, .09, .05])
    results.append({
        "order_id": oid,
        "tracking_number": f"JNX{rng.integers(10**9, 10**10)}",
        "delivery_status": status,
        "courier": {"name": str(rng.choice(["JNE", "SiCepat", "AnterAja"])),
                    "service": str(rng.choice(["REG", "YES", "ECO"]))},
        "destination": {"city": city, "province": PROV[city]},
        "timeline": {"shipped_at": f"2026-{rng.integers(8, 10):02d}-{rng.integers(1, 29):02d}",
                     "delivered_at": None if status != "Delivered" else
                     f"2026-{rng.integers(8, 10):02d}-{rng.integers(1, 29):02d}"},
    })
payload = {"status": "success", "count": len(results), "results": results}
with open(os.path.join(BASE, "logistik_mock.json"), "w", encoding="utf-8") as f:
    json.dump(payload, f, indent=2, ensure_ascii=False)

print("Dataset dummy dibuat:", len(trx), "transaksi |", len(customers), "pelanggan |",
      len(results), "paket logistik")
